#!/usr/bin/env python

# pywine - A wine rating system written in python using PyGTK
# Copyright (C) 2006 Mark Mruss <selsine@gmail.com>
# http://www.learningpython.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Library General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# If you find any bugs or have any suggestions email: selsine@gmail.com
# URL: http://www.learningpython.com

__author__ = "Mark Mruss <selsine@gmail.com>"
__version__ = "0.1"
__date__ = "Date: 2006/08/20"
__copyright__ = "Copyright (c) 2006 Mark Mruss"
__license__ = "GPL"

import sys
try:
 	import pygtk
  	pygtk.require("2.0")
except:
  	pass
try:
	import gtk
  	import gtk.glade
  	import gobject
  	import shelve
  	import os
except:
	sys.exit(1)

FILE_EXT = "pwi"

class pyWine:
	"""This is an Hello World GTK application"""

	def __init__(self):

		#print "Script dir: ", os.path.realpath(os.path.dirname(sys.argv[0]))
		# Set the project file
		self.project_file = ""

		#Set the Glade file
		self.gladefile = "pywine.glade"
		self.wTree = gtk.glade.XML(self.gladefile, "mainWindow")

		#Create our dictionay and connect it
		dic = {"on_mainWindow_destroy" : self.on_Quit
				, "on_AddWine" : self.OnAddWine
				, "on_EditWine" : self.on_EditWine
				, "on_file_open" : self.on_file_open
				, "on_file_save" : self.on_file_save}
		self.wTree.signal_autoconnect(dic)

		#Here are some variables that can be reused later
		self.cWineObject = 0
		self.cWine = 1
		self.cWinery = 2
		self.cGrape = 3
		self.cYear = 4

		self.sWine = "Wine"
		self.sWinery = "Winery"
		self.sGrape = "Grape"
		self.sYear = "Year"

		#Get the treeView from the widget Tree
		self.wineView = self.wTree.get_widget("wineView")
		#Add all of the List Columns to the wineView
		self.AddWineListColumn(self.sWine, self.cWine)
		self.AddWineListColumn(self.sWinery, self.cWinery)
		self.AddWineListColumn(self.sGrape, self.cGrape)
		self.AddWineListColumn(self.sYear, self.cYear)

		#Create the listStore Model to use with the wineView
		self.wineList = gtk.ListStore(gobject.TYPE_PYOBJECT
									, gobject.TYPE_STRING
									, gobject.TYPE_STRING
									, gobject.TYPE_STRING
									, gobject.TYPE_STRING)
		#Attache the model to the treeView
		self.wineView.set_model(self.wineList)

	def AddWineListColumn(self, title, columnId):
		"""This function adds a column to the list view.
		First it create the gtk.TreeViewColumn and then set
		some needed properties"""

		column = gtk.TreeViewColumn(title, gtk.CellRendererText()
			, text=columnId)
		column.set_resizable(True)
		column.set_sort_column_id(columnId)
		self.wineView.append_column(column)

	def on_Quit(self, widget):
		"""Called when the application is going to quit"""
		gtk.main_quit()

	def on_EditWine(self, widget):
		"""Called when the user wants to edit a wine entry"""

		# Get the selection in the gtk.TreeView
		selection = self.wineView.get_selection()
		# Get the selection iter
		model, selection_iter = selection.get_selected()

		if (selection_iter):
			"""There is a selection, so now get the the value at column
			self.cWineObject, the Wine Object"""
			wine = self.wineList.get_value(selection_iter, self.cWineObject)
			# Create the wine dialog, based off of the current selection
			wineDlg = wineDialog(wine);
			result,newWine = wineDlg.run()

			if (result == gtk.RESPONSE_OK):
				"""The user clicked Ok, so let's save the changes back
				into the gtk.ListStore"""
				self.wineList.set(selection_iter
						, self.cWineObject, newWine
						, self.cWine, newWine.wine
						, self.cWinery, newWine.winery
						, self.cGrape, newWine.grape
						, self.cYear, newWine.year)


	def OnAddWine(self, widget):
		"""Called when the use wants to add a wine"""
		# Create the dialog, show it, and store the results
		wineDlg = wineDialog();
		result,newWine = wineDlg.run()

		if (result == gtk.RESPONSE_OK):
			"""The user clicked Ok, so let's add this
			wine to the wine list"""
			self.wineList.append(newWine.getList())

	def on_file_open(self, widget):
		"""Called when the user wants to open a wine"""

		# Get the file to open
		open_file = self.file_browse(gtk.FILE_CHOOSER_ACTION_OPEN)
		if (open_file != ""):
			# We have a path, open it for reading
			try:
				db = shelve.open(open_file,"r")
				if (db):
					# We have opened the file, so empty out our gtk.TreeView
					self.wineList.clear()
					""" Since the shelve file is not gaurenteed to be in order we
					move through the file starting at iter 0 and moving our
					way up"""
					count = 0;
					while db.has_key(str(count)):
						newwine = db[str(count)]
						self.wineList.append(newwine.getList())
						count = count +1
					db.close();
					#set the project file
					root, self.project_file = os.path.split(open_file)
				else:
					self.show_error_dlg("Error opening file")
			except:
				self.show_error_dlg("Error opening file")

	def on_file_save(self, widget):
		"""Called when the user wants to save a wine list"""

		# Get the File Save path
		save_file = self.file_browse(gtk.FILE_CHOOSER_ACTION_SAVE, self.project_file)
		if (save_file != ""):
			# We have a path, ensure the proper extension
			save_file, extension = os.path.splitext(save_file)
			save_file = save_file + "." + FILE_EXT
			""" Now we have the "real" file save loction create
			the shelve file, use "n" to create a new file"""
			db = shelve.open(save_file,"n")
			"""Get the first item in the gtk.ListStore, and while it is not
			None, move forwqard through the list saving each item"""
			# Get the first item in the list
			iter = self.wineList.get_iter_root()
			while (iter):
				# Get the wine at the current gtk.TreeIter
				wine = self.wineList.get_value(iter, self.cWineObject)
				# Use the iters position in the list as the key name
				db[self.wineList.get_string_from_iter(iter)] = wine
				# Get the next iter
				iter = self.wineList.iter_next(iter)
			#close the database and write changes to disk, we are done
			db.close();
			#set the project file
			root, self.project_file = os.path.split(save_file)

	def file_browse(self, dialog_action, file_name=""):
		"""This function is used to browse for a pyWine file.
		It can be either a save or open dialog depending on
		what dialog_action is.
		The path to the file will be returned if the user
		selects one, however a blank string will be returned
		if they cancel or do not select one.
		dialog_action - The open or save mode for the dialog either
		gtk.FILE_CHOOSER_ACTION_OPEN, gtk.FILE_CHOOSER_ACTION_SAVE"""

		if (dialog_action==gtk.FILE_CHOOSER_ACTION_OPEN):
			dialog_buttons = (gtk.STOCK_CANCEL
								, gtk.RESPONSE_CANCEL
								, gtk.STOCK_OPEN
								, gtk.RESPONSE_OK)
		else:
			dialog_buttons = (gtk.STOCK_CANCEL
								, gtk.RESPONSE_CANCEL
								, gtk.STOCK_SAVE
								, gtk.RESPONSE_OK)

		file_dialog = gtk.FileChooserDialog(title="Select Project"
					, action=dialog_action
					, buttons=dialog_buttons)
		"""set the filename if we are saving"""
		if (dialog_action==gtk.FILE_CHOOSER_ACTION_SAVE):
			file_dialog.set_current_name(file_name)
		"""Create and add the pywine filter"""
		filter = gtk.FileFilter()
		filter.set_name("pyWine database")
		filter.add_pattern("*." + FILE_EXT)
		file_dialog.add_filter(filter)
		"""Create and add the 'all files' filter"""
		filter = gtk.FileFilter()
		filter.set_name("All files")
		filter.add_pattern("*")
		file_dialog.add_filter(filter)

		"""Init the return value"""
		result = ""
		if file_dialog.run() == gtk.RESPONSE_OK:
			result = file_dialog.get_filename()
		file_dialog.destroy()

		return result

	def show_error_dlg(self, error_string):
		"""This Function is used to show an error dialog when
		an error occurs.
		error_string - The error string that will be displayed
		on the dialog.
		"""
		error_dlg = gtk.MessageDialog(type=gtk.MESSAGE_ERROR
					, message_format=error_string
					, buttons=gtk.BUTTONS_OK)
		error_dlg.run()
		error_dlg.destroy()

class wineDialog:
	"""This class is used to show wineDlg"""

	def __init__(self, wine=None):
		"""Initialize the class.
		wine - a Wine object"""

		#setup the glade file
		self.gladefile = "pywine.glade"
		#setup the wine that we will return
		if (wine):
			#They have passed a wine object
			self.wine = wine
		else:
			#Just use a blank wine
			self.wine = Wine()

	def run(self):
		"""This function will show the wineDlg"""

		#load the dialog from the glade file
		self.wTree = gtk.glade.XML(self.gladefile, "wineDlg")
		#Get the actual dialog widget
		self.dlg = self.wTree.get_widget("wineDlg")
		#Get all of the Entry Widgets and set their text
		self.enWine = self.wTree.get_widget("enWine")
		self.enWine.set_text(self.wine.wine)
		self.enWinery = self.wTree.get_widget("enWinery")
		self.enWinery.set_text(self.wine.winery)
		self.enGrape = self.wTree.get_widget("enGrape")
		self.enGrape.set_text(self.wine.grape)
		self.enYear = self.wTree.get_widget("enYear")
		self.enYear.set_text(self.wine.year)

		#run the dialog and store the response
		self.result = self.dlg.run()
		#get the value of the entry fields
		self.wine.wine = self.enWine.get_text()
		self.wine.winery = self.enWinery.get_text()
		self.wine.grape = self.enGrape.get_text()
		self.wine.year = self.enYear.get_text()

		#we are done with the dialog, destory it
		self.dlg.destroy()

		#return the result and the wine
		return self.result,self.wine


class Wine:
	"""This class represents all the wine information"""

	def __init__(self, wine="", winery="", grape="", year=""):

		self.wine = wine
		self.winery = winery
		self.grape = grape
		self.year = year

	def getList(self):
		"""This function returns a list made up of the
		wine information.  It is used to add a wine to the
		wineList easily"""
		return [self, self.wine, self.winery, self.grape, self.year]

if __name__ == "__main__":
	wine = pyWine()
	gtk.main()
